package com.example.rivera_examen_ejercicio11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
