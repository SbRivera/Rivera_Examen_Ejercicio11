import 'package:flutter/material.dart';
import 'ui/VistaTriangulo.dart';

void main() {
  runApp(AplicacionTriangulo());
}

class AplicacionTriangulo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Generador de Triángulo con Asteriscos',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: VistaTriangulo(),
    );
  }
}
