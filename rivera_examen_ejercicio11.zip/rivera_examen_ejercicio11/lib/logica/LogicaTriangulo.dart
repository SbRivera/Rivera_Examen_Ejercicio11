class ControladorTriangulo {
  static String generarTriangulo(int altura) {
    StringBuffer triangulo= StringBuffer();
    for (int i = 1; i <= altura; i++) {
      triangulo.writeln('*' * i);
    }
    return triangulo.toString();
  }
}
/*
class ControladorTriangulo {
  static String generarTriangulo(int altura) {
    String resultado = '';
    for (int i = 1; i <= altura; i++) {
      resultado += '*' * i + '\n';
    }
    return resultado;
  }
}
*/
