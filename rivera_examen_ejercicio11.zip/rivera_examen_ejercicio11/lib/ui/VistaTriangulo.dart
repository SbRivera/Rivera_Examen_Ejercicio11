import 'package:flutter/material.dart';
import '../logica/LogicaTriangulo.dart';

class VistaTriangulo extends StatefulWidget {
  @override
  _VistaTrianguloState createState() => _VistaTrianguloState();
}

class _VistaTrianguloState extends State<VistaTriangulo> {
  final TextEditingController _controladorAltura = TextEditingController();
  String _salidaTriangulo = '';
  String _mensajeError = '';

  void _generarTriangulo() {
    setState(() {
      int? altura = int.tryParse(_controladorAltura.text);

      // Validaciones
      if (altura == null) {
        _mensajeError = 'Por favor, introduce un número válido.';
        _salidaTriangulo = '';
      } else if (altura < 1 || altura > 30) {
        _mensajeError =
        'Introduce un número entre 1 y 30. ¡Sin negativos ni decimales!';
        _salidaTriangulo = '';
      } else {
        _mensajeError = '';
        _salidaTriangulo = ControladorTriangulo.generarTriangulo(altura);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Generador de triangulos',
            style: TextStyle(fontFamily: 'Comic Sans MS'),
          ),
        ),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Container(
        color: Colors.blue[50], // Fondo celeste claro
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Escribe la altura del triangulo',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'Comic Sans MS',
                fontSize: 24,
                color: Colors.blue[900],
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _controladorAltura,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Introduce un número entre 1 y 30',
                labelStyle: TextStyle(
                  fontFamily: 'Comic Sans MS',
                  color: Colors.blue[700],
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20.0),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            SizedBox(height: 8),
            if (_mensajeError.isNotEmpty)
              Text(
                _mensajeError,
                style: TextStyle(
                  color: Colors.red,
                  fontFamily: 'Comic Sans MS',
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _generarTriangulo,
              child: Text(
                'Generar',
                style: TextStyle(
                  color: Colors.white, // Letras blancas
                  fontFamily: 'Comic Sans MS',
                  fontSize: 18,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.lightBlue,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: Container(
                padding: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.lightBlue[50],
                  border: Border.all(color: Colors.blue[300]!, width: 3),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: SingleChildScrollView(
                  child: Text(
                    _salidaTriangulo,
                    style: TextStyle(
                      fontFamily: 'Courier',
                      fontSize: 18,
                      color: Colors.blue[900],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
